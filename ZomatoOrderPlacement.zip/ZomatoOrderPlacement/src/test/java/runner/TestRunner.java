package runner;

import tests.SearchTests;

public class TestRunner {
	
	public static void main(String[] args) {
		
		SearchTests searchTests=new SearchTests();
		searchTests.searchPizzaTest();
	}

}
