package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utility.BaseTest;

public class SearchPage extends BaseTest {

	WebDriver driver;

	public By loginBtn = By.xpath("//a[text()='Log in']");
	public By searchBtn = By.xpath("//input[@placeholder='Search for restaurant, cuisine or a dish']");
	public By peppyPannerMenu = By.xpath("//p[text()='Peppy Paneer Pizza - Delivery']");
	public By restaurantHdr = By.xpath("//h1[text()='Food Delivery Restaurants in Bengaluru']");

	public void launchUrl() {

		driver = initiateChromeBrowser();
		driver.get("https://www.zomato.com/bangalore/dominos-pizza-shanti-nagar/order");
	}

	public void searchPizza() {

		waitForElement(searchBtn);
		driver.findElement(searchBtn).sendKeys("peppy panner");
		waitForElement(peppyPannerMenu);
		driver.findElement(peppyPannerMenu).click();
		waitForElement(restaurantHdr);
		driver.findElement(restaurantHdr);
	}
}
