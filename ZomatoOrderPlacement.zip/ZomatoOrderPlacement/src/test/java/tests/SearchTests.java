package tests;

import pages.SearchPage;

public class SearchTests {

	SearchPage searchPage = new SearchPage();

	public void searchPizzaTest() {
		searchPage.launchUrl();
		searchPage.searchPizza();
	}

}
